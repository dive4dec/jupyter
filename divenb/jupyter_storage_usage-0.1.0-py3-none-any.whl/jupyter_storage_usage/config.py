"""Configuration via environment variables.

All settings are env-var based so JupyterHub can inject them via extraEnv
without needing to modify the server config file.
"""

import os


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, str(default)))
    except ValueError:
        return default


def _env_str(key: str, default: str) -> str:
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool) -> bool:
    val = os.environ.get(key, "1" if default else "0")
    return val.lower() in ("1", "true", "yes", "on")


def _env_quantity(key: str, default: int) -> int:
    """Parse an env var as a K8s-style quantity or plain bytes.

    Accepts: "10Gi", "500Mi", "1Ti", "21474836480", etc.
    Falls back to plain int, then default.
    """
    raw = os.environ.get(key, "")
    if not raw:
        return default
    # Try plain int first (fast path)
    try:
        return int(raw)
    except ValueError:
        pass
    # Try K8s quantity parsing
    try:
        from .quantity import parse_quantity
        return parse_quantity(raw)
    except (ValueError, ImportError):
        return default


# Directory to monitor
HOME_DIR = _env_str("JSU_HOME_DIR", "/home/jovyan")

# Soft limit — show warning in UI
WARN_LIMIT_BYTES = _env_quantity("JSU_WARN_LIMIT_BYTES", 50 * 1024**3)

# Hard limit — hub will cull + block spawn; server goes read-only
HARD_LIMIT_BYTES = _env_quantity("JSU_HARD_LIMIT_BYTES", 100 * 1024**3)

# How often to check usage locally (seconds)
# Default: 1800 (30 min). Persistent cache on NFS means staleness is acceptable.
CHECK_INTERVAL_SEC = _env_int("JSU_CHECK_INTERVAL_SEC", 1800)

# ── Cleanup mode ────────────────────────────────────────────────────────
# When JSU_CLEANUP_MODE=1, the server extension takes over the root URL
# and serves the cleanup portal (restricted file manager) instead of
# the normal JupyterLab interface. This is set by the pre-spawn hook
# when a user is over their storage limit.
CLEANUP_MODE = _env_bool("JSU_CLEANUP_MODE", False)
