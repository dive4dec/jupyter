"""jupyterhub-storage-usage: JupyterHub service for storage monitoring, culling, and dashboard."""

from ._version import __version__

__all__ = ["__version__"]
