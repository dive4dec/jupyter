"""Configuration via environment variables.

All settings are env-var based, matching how jupyterhub-idle-culler works.
"""

import os


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, str(default)))
    except ValueError:
        return default


def _env_str(key: str, default: str) -> str:
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool) -> bool:
    val = os.environ.get(key, "1" if default else "0")
    return val.lower() in ("1", "true", "yes", "on")


def _env_quantity(key: str, default: int) -> int:
    """Parse an env var as a K8s-style quantity or plain bytes.

    Accepts: "10Gi", "500Mi", "1Ti", "21474836480", etc.
    Falls back to plain int, then default.
    """
    raw = os.environ.get(key, "")
    if not raw:
        return default
    # Try plain int first (fast path)
    try:
        return int(raw)
    except ValueError:
        pass
    # Try K8s quantity parsing
    try:
        from .quantity import parse_quantity
        return parse_quantity(raw)
    except (ValueError, ImportError):
        return default


# ── Limits ──────────────────────────────────────────────────────────────
WARN_LIMIT_BYTES = _env_quantity("JSU_WARN_LIMIT_BYTES", 50 * 1024**3)
HARD_LIMIT_BYTES = _env_quantity("JSU_HARD_LIMIT_BYTES", 100 * 1024**3)

# ── Polling ─────────────────────────────────────────────────────────────
POLL_INTERVAL_SEC = _env_int("JSU_POLL_INTERVAL_SEC", 300)
MAX_CONCURRENT_POLLS = _env_int("JSU_MAX_CONCURRENT_POLLS", 50)

# ── Culling ─────────────────────────────────────────────────────────────
CULL_ON_HARD_LIMIT = _env_bool("JSU_CULL_ON_HARD_LIMIT", True)
GRACE_PERIOD_SEC = _env_int("JSU_GRACE_PERIOD_SEC", 0)

# ── Pre-spawn ───────────────────────────────────────────────────────────
ADMIN_CAN_SPAWN_OVER_LIMIT = _env_bool("JSU_ADMIN_CAN_SPAWN_OVER_LIMIT", True)

# ── Cleanup pod ─────────────────────────────────────────────────────────
# When a user is over limit, the pre-spawn hook swaps their image to this
# and sets low resource limits. The cleanup pod runs jupyter-storage-usage
# in CLEANUP_MODE=1 (file manager only, no JupyterLab).
CLEANUP_ENABLED = _env_bool("JSU_CLEANUP_ENABLED", True)
CLEANUP_IMAGE = _env_str("JSU_CLEANUP_IMAGE", "")
CLEANUP_MEM_LIMIT = _env_str("JSU_CLEANUP_MEM_LIMIT", "256M")
CLEANUP_CPU_LIMIT = _env_str("JSU_CLEANUP_CPU_LIMIT", "0.5")
CLEANUP_MEM_GUARANTEE = _env_str("JSU_CLEANUP_MEM_GUARANTEE", "128M")
CLEANUP_CPU_GUARANTEE = _env_str("JSU_CLEANUP_CPU_GUARANTEE", "0.1")

# ── Exclusions ──────────────────────────────────────────────────────────
EXCLUDE_USERS = [
    u.strip() for u in _env_str("JSU_EXCLUDE_USERS", "").split(",") if u.strip()
]

# ── Cache ───────────────────────────────────────────────────────────────
CACHE_DB_PATH = _env_str("JSU_CACHE_DB_PATH", "/tmp/storage-usage.db")

# ── JupyterHub connection ───────────────────────────────────────────────
# JUPYTERHUB_API_URL is injected by JupyterHub when spawning the service.
# It typically points at http://hub:8081/... but the `hub` DNS may not
# be reachable from the hub pod itself (the service IP doesn't accept
# loopback connections from the same pod).  Fall back to localhost.
HUB_API_TOKEN = _env_str("JUPYTERHUB_API_TOKEN", "")
HUB_API_URL = _env_str("JUPYTERHUB_API_URL", "http://localhost:8081/hub/api")
# Rewrite hub:8081 → localhost:8081 when running inside the hub pod
if HUB_API_URL.startswith("http://hub:"):
    HUB_API_URL = HUB_API_URL.replace("http://hub:", "http://localhost:", 1)
