"""JupyterHub LiteLLM API key management."""

import os
import sqlite3
import logging
import aiohttp
import yaml
from datetime import datetime, timezone as dt_timezone, timedelta
import re
from jupyterhub.handlers import BaseHandler
from tornado import web

log = logging.getLogger("jupyterhub.litellm")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
LITELLM_PROXY_URL = os.environ.get(
    "LITELLM_PROXY_URL",
    "http://litellm.litellm-proxy.svc.cluster.local:4000",
)
LITELLM_MASTER_KEY = os.environ.get("LITELLM_MASTER_KEY", "")
LITELLM_DB_PATH = os.environ.get("LITELLM_DB_PATH", "/srv/jupyterhub/jupyterhub.sqlite")
LITELLM_API_ENDPOINT = os.environ.get(
    "LITELLM_API_ENDPOINT",
    "https://socratic.cs.cityu.edu.hk/litellm/v1",
)
LITELLM_MODEL_NAME = os.environ.get("LITELLM_MODEL_NAME", "Socrates")
LITELLM_LIMITS_PATH = os.environ.get(
    "LITELLM_LIMITS_PATH",
    "/srv/jupyterhub/jupyterhub-litellm/jupyterhub_litellm/litellm_limits.yaml",
)


def parse_duration_to_timedelta(duration_str):
    """Parse LiteLLM budget_duration string (e.g. '24h', '30d', '15m') to timedelta."""
    if not duration_str:
        return None
    m = re.match(r'^(\d+(?:\.\d+)?)\s*(s|m|h|d)$', str(duration_str).strip())
    if not m:
        log.warning("Cannot parse budget_duration: %r", duration_str)
        return None
    value = float(m.group(1))
    unit = m.group(2)
    if unit == 's':
        return timedelta(seconds=value)
    elif unit == 'm':
        return timedelta(minutes=value)
    elif unit == 'h':
        return timedelta(hours=value)
    elif unit == 'd':
        return timedelta(days=value)


def load_budget_config():
    """Load budget limits config (defaults + per-user overrides)."""
    try:
        with open(LITELLM_LIMITS_PATH) as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        log.warning("Budget config not found at %s", LITELLM_LIMITS_PATH)
        return {"defaults": {"max_budget": -1, "duration": "30d"}, "per_user": {}}


def get_user_limits(username):
    """Return resolved limits for *username* as a LiteLLM key payload."""
    cfg = load_budget_config()
    defaults = cfg.get("defaults") or {}
    per_user = cfg.get("per_user") or {}
    override = per_user.get(username, {})
    
    # Merge: per-user override > defaults
    limits = dict(defaults)
    limits.update(override)
    
    # Build LiteLLM key payload from limits
    payload = {}
    if limits.get("max_budget") is not None and limits["max_budget"] != -1:
        payload["max_budget"] = limits["max_budget"]
    if limits.get("budget_duration"):
        payload["budget_duration"] = limits["budget_duration"]
    if limits.get("tpm_limit") is not None and limits["tpm_limit"] != -1:
        payload["tpm_limit"] = limits["tpm_limit"]
    if limits.get("rpm_limit") is not None and limits["rpm_limit"] != -1:
        payload["rpm_limit"] = limits["rpm_limit"]
    payload["duration"] = limits.get("duration") or "30d"
    
    return payload


# ---------------------------------------------------------------------------
# Database helpers — only stores key reference, NOT spend
# ---------------------------------------------------------------------------
def get_litellm_db():
    con = sqlite3.connect(LITELLM_DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS litellm_keys (
            username TEXT PRIMARY KEY,
            key      TEXT NOT NULL,
            key_name TEXT,
            token_id TEXT,
            created_at TEXT,
            expires_at TEXT,
            last_regenerated_at TEXT DEFAULT NULL
        )
    """)
    # Migration: add last_regenerated_at if it doesn't exist
    cur = con.cursor()
    cur.execute("PRAGMA table_info(litellm_keys)")
    columns = [row[1] for row in cur.fetchall()]
    if "last_regenerated_at" not in columns:
        con.execute("ALTER TABLE litellm_keys ADD COLUMN last_regenerated_at TEXT DEFAULT NULL")
        log.info("Migrated litellm_keys: added last_regenerated_at column")
    con.commit()
    return con


def get_user_key(username):
    con = get_litellm_db()
    try:
        cur = con.cursor()
        cur.execute("SELECT * FROM litellm_keys WHERE username = ?", (username,))
        row = cur.fetchone()
        if row is None:
            return None
        return dict(zip([d[0] for d in cur.description], row))
    finally:
        con.close()


def save_user_key(username, kd, last_regenerated_at=None):
    con = get_litellm_db()
    try:
        # Use UPDATE for last_regenerated_at to preserve it if not passed
        con.execute(
            "INSERT OR REPLACE INTO litellm_keys (username, key, key_name, token_id, created_at, expires_at, last_regenerated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (username, kd.get("key", ""), kd.get("key_name", ""),
             kd.get("token_id", ""), kd.get("created_at", ""), kd.get("expires", ""),
             last_regenerated_at),
        )
        con.commit()
    finally:
        con.close()


async def call_litellm_api(path, method="GET", data=None):
    url = f"{LITELLM_PROXY_URL}{path}"
    headers = {"Authorization": f"Bearer {LITELLM_MASTER_KEY}", "Content-Type": "application/json"}
    async with aiohttp.ClientSession() as sess:
        async with sess.request(method, url, headers=headers, json=data) as resp:
            return await resp.json()


async def get_key_info(token_id):
    """Query LiteLLM proxy for key info: spend, max_budget, budget_duration, etc."""
    try:
        url = f"{LITELLM_PROXY_URL}/key/info"
        headers = {"Authorization": f"Bearer {LITELLM_MASTER_KEY}"}
        async with aiohttp.ClientSession() as sess:
            async with sess.get(url, headers=headers, params={"key": token_id}) as resp:
                if resp.status == 200:
                    return (await resp.json()).get("info", {})
    except Exception as exc:
        log.warning("Failed to get key info: %s", exc)
    return None

# ---------------------------------------------------------------------------
# Tornado handler
# ---------------------------------------------------------------------------
class LiteLLMKeyHandler(BaseHandler):
    """Render the LiteLLM API key page and handle key generation."""

    def check_xsrf_cookie(self):
        pass

    async def get(self):
        """Render the LiteLLM key page (GET)."""
        user = self.current_user
        if not user:
            self.redirect(f"/hub/login?next={self.request.uri}")
            return

        ki = get_user_key(user.name)
        has_key = ki and ki.get("key")
        key_value = ki["key"] if has_key else None
        expires = ki["expires_at"] if has_key and ki.get("expires_at") else ""
        generated = bool(self.get_argument("generated", ""))
        budget_exceeded = bool(self.get_argument("budget_exceeded", ""))
        delete_failed = bool(self.get_argument("delete_failed", ""))
        cooldown = bool(self.get_argument("cooldown", ""))
        remaining_hours = self.get_argument("remaining", "0")

        # Fetch live key info from proxy — this is the source of truth
        usage_info = {}
        if has_key and ki.get("token_id"):
            usage_info = await get_key_info(ki["token_id"]) or {}

        html = await self.render_template(
            "litellm_key_page.html",
            key_value=key_value,
            expires=expires,
            generated=generated,
            budget_exceeded=budget_exceeded,
            delete_failed=delete_failed,
            cooldown=cooldown,
            remaining_hours=remaining_hours,
            has_key=has_key,
            endpoint=LITELLM_API_ENDPOINT,
            model_name=LITELLM_MODEL_NAME,
            usage=usage_info,
            limits=get_user_limits(user.name),
        )
        self.finish(html)

    async def post(self):
        """Generate / regenerate the LiteLLM API key (POST)."""
        user = self.current_user
        if not user:
            self.redirect(f"/hub/login?next={self.request.uri}")
            return

        action = self.get_argument("action", "")
        if action == "generate":
            existing = get_user_key(user.name)
            old_key_spend = 0

            # Regenerate: capture old key spend, delete old key
            total_spend = 0
            if existing and existing.get("token_id"):
                old_info = await get_key_info(existing["token_id"])
                old_key_spend = (old_info.get("spend", 0) or 0) if old_info else 0
                # Add cumulative spend from all prior keys
                prior_cumulative = existing.get("cumulative_spend", 0) or 0
                total_spend = prior_cumulative + old_key_spend

                resp = await call_litellm_api(
                    "/key/delete", "POST", {"keys": [existing["token_id"]]}
                )
                if isinstance(resp, dict) and resp.get("error"):
                    log.warning("Failed to delete key for %s: %s", user.name, resp)
                    self.redirect(f"{self.hub.base_url}litellm-key?delete_failed=1")
                    return
                log.info("Deleted old key(s) for %s (key spend: %.4f, cumulative: %.4f)",
                         user.name, old_key_spend, total_spend)

            # Build payload from current limits
            payload = get_user_limits(user.name)
            payload["models"] = [LITELLM_MODEL_NAME]
            payload["user"] = user.name
            payload["metadata"] = {"username": user.name}

            # If regenerating, carry over total cumulative spend by reducing max_budget
            if payload.get("max_budget") and total_spend > 0:
                payload["max_budget"] = max(payload["max_budget"] - total_spend, 0)

            result = await call_litellm_api("/key/generate", "POST", payload)

            if "key" in result:
                # Pass cumulative_spend so it gets persisted to SQLite
                result["cumulative_spend"] = total_spend
                save_user_key(user.name, result)
                self.redirect(f"{self.hub.base_url}litellm-key?generated=1")
            else:
                self.write(f"Error generating key: {result}")
        else:
            self.write("Invalid action")

def load_jupyterhub_extension(jp_config):
    """Called automatically when JupyterHub loads this package.

    Handler registration is handled by the deployment's jupyterhub_config.py
    via extra_handlers — this entry point is a no-op.
    """
    pass

