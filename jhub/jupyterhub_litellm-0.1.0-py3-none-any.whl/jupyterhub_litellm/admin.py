"""Admin helpers for LiteLLM key management."""

import sqlite3
import logging
import yaml

import aiohttp
from jupyterhub.handlers import BaseHandler
from tornado import web
from jupyterhub_litellm import (
    get_user_key, call_litellm_api, get_key_info, get_user_limits,
    get_litellm_db, save_user_key, LITELLM_MODEL_NAME, LITELLM_LIMITS_PATH,
    load_budget_config, log,
)


async def admin_regenerate_key(username):
    """Admin regenerates key for user — no cooldown, full budget."""
    from . import get_user_key, call_litellm_api, get_key_info, save_user_key, LITELLM_MODEL_NAME
    existing = get_user_key(username)
    if existing and existing.get("token_id"):
        await call_litellm_api("/key/delete", "POST", {"keys": [existing["token_id"]]})

    payload = get_user_limits(username)
    payload["models"] = [LITELLM_MODEL_NAME]
    payload["user"] = username
    payload["metadata"] = {"username": username}

    result = await call_litellm_api("/key/generate", "POST", payload)
    if "key" in result:
        save_user_key(username, result)
        return True
    return False


class LiteLLMAdminHandler(BaseHandler):
    """Admin page for managing all users' LiteLLM keys."""

    def check_xsrf_cookie(self):
        pass

    async def get(self):
        if not self.current_user or not self.has_scope("admin:users"):
            self.redirect(self.hub.base_url + "home")
            return
        users_data = await self._get_all_users_key_info()
        html = await self.render_template(
            "litellm-admin.html",
            users=users_data,
            limits_cfg=load_budget_config(),
            success=self.get_query_argument("success", ""),
            error=self.get_query_argument("error", ""),
            user_query=self.get_query_argument("user", ""),
        )
        self.finish(html)

    async def post(self):
        if not self.current_user or not self.has_scope("admin:users"):
            self.redirect(self.hub.base_url + "home")
            return
        username = self.get_argument("username", "")
        action = self.get_argument("action", "")
        if not username or not action:
            self.redirect(f"{self.hub.base_url}litellm-admin?error=missing_params")
            return

        if action == "regenerate":
            await self._admin_regenerate_key(username)
        elif action == "block":
            await self._admin_block_key(username)
        elif action == "unblock":
            await self._admin_unblock_key(username)
        elif action == "update_limits":
            await self._admin_update_limits(username)
        else:
            self.redirect(f"{self.hub.base_url}litellm-admin?error=unknown_action")
            return

    async def _get_all_users_key_info(self):
        con = get_litellm_db()
        try:
            cur = con.execute("SELECT username FROM litellm_keys ORDER BY username")
            rows = cur.fetchall()
        finally:
            con.close()

        users = []
        for (username,) in rows:
            ki = get_user_key(username)
            if not ki or not ki.get("token_id"):
                users.append({"username": username, "has_key": False})
                continue
            info = await get_key_info(ki["token_id"]) or {}
            users.append({
                "username": username,
                "has_key": True,
                "token_id": ki["token_id"],
                "key": ki["key"],
                "spend": info.get("spend", 0) or 0,
                "max_budget": info.get("max_budget"),
                "budget_duration": info.get("budget_duration") or "",
                "tpm_limit": info.get("tpm_limit"),
                "rpm_limit": info.get("rpm_limit"),
                "blocked": info.get("blocked", False),
                "expires": info.get("expires") or ki.get("expires_at", ""),
                "models": info.get("models", []),
                "last_regenerated_at": ki.get("last_regenerated_at") or "",
            })
        return users

    async def _admin_regenerate_key(self, username):
        """Admin regenerate — no cooldown, full budget."""
        existing = get_user_key(username)
        if existing and existing.get("token_id"):
            await call_litellm_api("/key/delete", "POST", {"keys": [existing["token_id"]]})

        payload = get_user_limits(username)
        payload["models"] = [LITELLM_MODEL_NAME]
        payload["user"] = username
        payload["metadata"] = {"username": username}

        result = await call_litellm_api("/key/generate", "POST", payload)
        if "key" in result:
            save_user_key(username, result)
            self.redirect(f"{self.hub.base_url}litellm-admin?success=regenerated&user={username}")
        else:
            self.redirect(f"{self.hub.base_url}litellm-admin?error=regen_failed&user={username}")

    async def _admin_block_key(self, username):
        existing = get_user_key(username)
        if not existing or not existing.get("key"):
            self.redirect(f"{self.hub.base_url}litellm-admin?error=no_key&user={username}")
            return
        await call_litellm_api("/key/update", "POST", {"key": existing["key"], "blocked": True})
        self.redirect(f"{self.hub.base_url}litellm-admin?success=blocked&user={username}")

    async def _admin_unblock_key(self, username):
        existing = get_user_key(username)
        if not existing or not existing.get("key"):
            self.redirect(f"{self.hub.base_url}litellm-admin?error=no_key&user={username}")
            return
        await call_litellm_api("/key/update", "POST", {"key": existing["key"], "blocked": False})
        self.redirect(f"{self.hub.base_url}litellm-admin?success=unblocked&user={username}")

    async def _admin_update_limits(self, username):
        existing = get_user_key(username)
        if not existing or not existing.get("key"):
            self.redirect(f"{self.hub.base_url}litellm-admin?error=no_key&user={username}")
            return
        update_payload = {"key": existing["key"]}
        for field in ["max_budget", "budget_duration", "tpm_limit", "rpm_limit", "duration"]:
            val = self.get_argument(field, "")
            if val:
                try:
                    update_payload[field] = float(val) if "." in val else int(val)
                except (ValueError, TypeError):
                    update_payload[field] = val
        await call_litellm_api("/key/update", "POST", update_payload)
        self.redirect(f"{self.hub.base_url}litellm-admin?success=limits_updated&user={username}")



