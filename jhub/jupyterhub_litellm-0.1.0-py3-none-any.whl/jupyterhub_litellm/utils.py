"""Utility constants for jupyterhub-litellm."""

import os

# Absolute path to this package's handler templates folder.
# Append to c.JupyterHub.template_paths so Jinja2 can find litellm_key_page.html,
# litellm-admin.html, and page.html when handlers render them.
LITELLM_TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")

